package org.mockito.internal.exceptions;

public class MockitoLimitations {

    public final static String NON_PUBLIC_PARENT = "Mocking methods declared on non-public parent classes is not supported.";

}
